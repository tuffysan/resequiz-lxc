Resequiz v2.1 Offline
=====================
Kör START-QUIZ.cmd på Windows eller öppna index.html direkt.

Nytt:
- Profilavatarer
- Modern game-show-design
- Fullskärmsläge under frågor
- 2 440 frågor i 14 kategorier
- Anti-repeat och PWA/offline-stöd
